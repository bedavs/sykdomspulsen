.onLoad <- function(libname, pkgname) {
  check_env_vars()

  set_db()
  set_computer_type()
  set_progressr()

  invisible()
}

check_env_vars <- function(){
  needed <- c(
    "SYKDOMSPULSEN_DB_DRIVER",
    "SYKDOMSPULSEN_DB_SERVER",
    "SYKDOMSPULSEN_DB_PORT",
    "SYKDOMSPULSEN_DB_USER",
    "SYKDOMSPULSEN_DB_PASSWORD",
    "SYKDOMSPULSEN_DB_DB",
    "SYKDOMSPULSEN_DB_TRUSTED_CONNECTION",

    "SYKDOMSPULSEN_PRODUCTION",

    "SYKDOMSPULSEN_EMAIL_HOST",
    "SYKDOMSPULSEN_EMAIL_PORT",
    "SYKDOMSPULSEN_EMAIL_USERNAME",
    "SYKDOMSPULSEN_EMAIL_PASSWORD",
    "SYKDOMSPULSEN_EMAIL_AUTHOR"

  )

  for(i in needed){
    getval <- Sys.getenv(i)
    if(getval==""){
      packageStartupMessage(glue::glue("{crayon::red(i)}=''"))
    } else {
      packageStartupMessage(glue::glue("{crayon::green(i)}='{getval}'"))
    }
  }

}

set_db <- function(){
  config$db_config <- list(
    driver = Sys.getenv("SYKDOMSPULSEN_DB_DRIVER", "MySQL"),
    server = Sys.getenv("SYKDOMSPULSEN_DB_SERVER", "db"),
    port = as.integer(Sys.getenv("SYKDOMSPULSEN_DB_PORT", 1433)),
    user = Sys.getenv("SYKDOMSPULSEN_DB_USER", "root"),
    password = Sys.getenv("SYKDOMSPULSEN_DB_PASSWORD", "example"),
    db = Sys.getenv("SYKDOMSPULSEN_DB_DB", "sykdomspuls"),
    trusted_connection = Sys.getenv("SYKDOMSPULSEN_DB_TRUSTED_CONNECTION")
  )
}

set_computer_type <- function() {
  if (Sys.getenv("SYKDOMSPULSEN_PRODUCTION") == "1") {
    config$is_production <- TRUE
  }
}

set_progressr <- function(){
  progressr::handlers(progressr::handler_progress(
    format = "[:bar] :current/:total (:percent) in :elapsedfull, eta: :eta",
    clear = FALSE
  ))
}

