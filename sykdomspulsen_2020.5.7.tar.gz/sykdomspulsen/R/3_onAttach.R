.onAttach <- function(libname, pkgname) {
  packageStartupMessage(glue::glue("\n\nspulscore: {utils::packageVersion('sykdomspulsen')}"))
}
