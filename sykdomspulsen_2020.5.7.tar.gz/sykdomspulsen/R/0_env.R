#' Flags/values to be used
#' @export config
config <- new.env()

config$verbose <- FALSE
