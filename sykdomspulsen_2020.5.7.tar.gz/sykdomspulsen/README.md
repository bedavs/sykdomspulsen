# sykdomspulsen

Sykdomspulsen is a free and open-source health surveillance system designed and developed by the Norwegian Institute of Public Health. You can find out more information at https://sykdomspulsen-dokumentasjon.no/
