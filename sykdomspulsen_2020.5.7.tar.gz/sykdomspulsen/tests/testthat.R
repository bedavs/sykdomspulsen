library(testthat)
library(spulscore)

test_check("spulscore")
