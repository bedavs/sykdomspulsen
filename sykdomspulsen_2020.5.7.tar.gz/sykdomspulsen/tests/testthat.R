library(testthat)
library(sykdomspulsen)

test_check("sykdomspulsen")
